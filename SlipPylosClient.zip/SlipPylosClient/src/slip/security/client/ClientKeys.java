package slip.security.client;


import slip.security.common.*;

public class ClientKeys {
	private static final String RSA_SERVER_PUBLIC_KEY  = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAl1mtOHavqo19NkFTnxuJaXZYmA5k5WAHC3yICpd0EZbgZgAI8YbolWmtJHOvY1OvTHXASzwTdqHlmTy0wVHF3rhtzGFe17lkfdZsWfwSrzIZtcB2bYWGHEY0I1LGBitGl+nA6mlw/gxYS++MQXABL3BMtSfPmSIzhX7Dm6/roH/gFPC5gx6/fwVHXi4yjFFD8AB8Q2/B2kS9pqE+3Zx9yHezFKuM3mTQyJuJTTOzNZVlyDlhvvnE6qK10591i0U3swSxH3Lj2ULt+nB7eAK+JK1S85759xOCrS/ftWzAnPAn07jHxm1JW4Edy0Ho7GX7MjvX2MK0h3u6BXKi4Ql+xQIDAQAB";
	
	
}
