/**
 * 
 * Fonctions de sécurité communes au client et serveur.
 * 
 */

/**
 * 
 * @author admin
 *
 */
package slip.security.common;