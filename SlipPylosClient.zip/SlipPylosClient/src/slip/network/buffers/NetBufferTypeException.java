package slip.network.buffers;

public class NetBufferTypeException extends Exception {
	private static final long serialVersionUID = -8785615402853344834L;
	// 
	
}
