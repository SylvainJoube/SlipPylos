package commun.partie.nonGraphique;

/**
 * Classe pour l'�criture de messages de d�bug & informations
 *
 */
public class Log {

	public static void log(String logStr) {
		System.out.println(logStr);
	}
	public static void write(String logStr) {
		System.out.println(logStr);
	}
	
}