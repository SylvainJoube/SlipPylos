package commun.partie.nonGraphique;

public class PylosPoint {
	public int x;
	public int y;
	public PylosPoint() {
		
	}
	public PylosPoint(int arg_x, int arg_y) {
		x = arg_x;
		y = arg_y;
	}
}
