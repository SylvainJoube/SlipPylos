package client.listeners;

public enum ListenerMouseEventType {
	MOVED,
	PRESSED,
	RELEASED;
}