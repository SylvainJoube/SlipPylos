package client.partie.graphique;

public enum RoomType {
	AUCUN,
	PARTIE,
	MENU_CHOIX_TYPE_PARTIE,
	MENU_RESEAU_LOCAL,
	MENU_INTERNET;
}
