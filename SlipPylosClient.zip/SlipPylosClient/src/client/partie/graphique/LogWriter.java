﻿package client.partie.graphique;

// Classe statique, écrivant les logs sur la console et dans un fichier
public class LogWriter {
	//public static LogWriter lWriter = new LogW
	
	
	public static void Log(String logStr) {
		System.out.println(logStr);
	}
}
