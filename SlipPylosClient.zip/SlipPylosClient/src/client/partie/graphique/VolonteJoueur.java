package client.partie.graphique;

public enum VolonteJoueur {
	PION_EN_MAIN_DEPUIS_RESERVE, // a pris un pion de sa réserve
	DEPLACER_UN_PION,
	REPRENDRE_UN_PION,
	MAIN_LIBRE;
}
