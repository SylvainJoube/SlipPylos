/**
 * 
 */
/** Première salle dans laquelle le joueur est : choix du type de partie :
 * Solo local, hot seat, réseau local, internet
 * 
 */
package client.room1;