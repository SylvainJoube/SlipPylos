/**
 * 
 */
/**
 * Fonctions graphiques utiles au client
 *
 */
package client.outils.graphiques;